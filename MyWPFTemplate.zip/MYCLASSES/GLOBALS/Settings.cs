﻿using $safeprojectname$.MyClasses;
using $safeprojectname$.MyWindows;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Navigation;

namespace $safeprojectname$
{
    public class Settings
    {
        // How To Add A Setting:
        // 1. Give it a unique name in SettingNames
        // 2. Create it in the region below
        //   2.1 Default value must be an argument in the constructor to work properly
        //   2.2 Assign a category like this: General/Examples 
        // 3. Add it to GetAllSettings()
        // 4. Add it to the relevent SetSetting() function

        // Objects & Variables
        public static Settings userSettings = new Settings();
        public const string defaultCategory = "General";

        private static string iconColour = "#FFFFFF";

        #region Settings

        // General
        public BoolSetting logDebugMessages = new BoolSetting(false) {
            name = SettingNames.logDebugMessages,
            description = "Only enable if you're gathering information for a bug report.",
            category = "General",
            isHidden = false,
            OnValueChanged = (bool newValue) => {
                Log.logDebugToFile = newValue;
                Log.Debug($"Set Log.logDebugToFile to '{newValue}'");
            }
        };
        public ButtonSetting showLog = new ButtonSetting() {
            name = SettingNames.showLog,
            description = $"Opens the folder that contains {ProgramData.programName}'s log file.",
            category = "General",
            isHidden = false,
            buttonText = "Show In Explorer",
            OnClick = delegate () { Process.Start(ProgramData.FilePaths.logsFolder); }
        };

        // Backups
        public BoolSetting autoBackups = new BoolSetting(true) {
            name = SettingNames.autoBackup,
            description = $"Whether {ProgramData.programName} should automatically backup your data on a clean exit.",
            category = "Backups",
            isHidden = false
        };
        public StringSetting backupsFolder = new StringSetting(BackupManager.defaultBackupsFolder) {
            name = SettingNames.backupsFolder,
            description = "Where data backups should be stored. A OneDrive location is recommended for important data.",
            category = "Backups",
            isHidden = false
        };
        public ButtonSetting browseForBackupsFolder = new ButtonSetting() {
            name = SettingNames.browseForBackupsFolder,
            description = "Browse for a folder to store backups in.",
            category = "Backups",
            buttonText = "Browse",
            OnClick = delegate () {
                System.Windows.Forms.FolderBrowserDialog browser = new System.Windows.Forms.FolderBrowserDialog();
                if (browser.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
                    userSettings.SetSetting(SettingNames.backupsFolder, browser.SelectedPath, false);
                }
            }
        };
        public IntSetting numBackups = new IntSetting(5) {
            name = SettingNames.numBackups,
            description = "The maximum number of data backups to keep.",
            category = "Backups",
            min = 1,
            max = 10
        };
        public ButtonSetting openBackups = new ButtonSetting() {
            name = SettingNames.openBackups,
            description = "Opens the Data Backup Management Window.",
            category = "Backups",
            buttonText = "Open Backup Manager",
            OnClick = delegate () { BackupManagementWindow.ShowBackupManagerWindow(); }
        };

        // Theme
        public ButtonSetting restoreDefaultTheme = new ButtonSetting() {
            name = SettingNames.restoreDefaultTheme,
            description = "Resets the theme to the default colours.",
            category = "Theme",
            buttonText = "Restore Default Theme",
            OnClick = delegate () {
                if (GuiUtils.GetUserConfirmation("Restore Default Theme?", "Are you sure you want to restore the default theme? This cannot be undone.")) {
                    userSettings.dimBackground.RestoreDefault();
                    userSettings.normalBackground.RestoreDefault();
                    userSettings.brightBackground.RestoreDefault();
                    userSettings.uiBackground.RestoreDefault();
                    userSettings.accentColour.RestoreDefault();
                    userSettings.textColour.RestoreDefault();
                    Save();
                    SettingsChanged?.Invoke(null, new SettingChangedEventArgs() { changeFromGUI = false });
                    LoadTheme();
                }
            }
        };
        public ColourSetting dimBackground = new ColourSetting(Color.FromRgb(35, 35, 35)) {
            name = SettingNames.dimBackground,
            description = $"The background colour of {ProgramData.programName}.",
            category = "Theme",
            isHidden = false,
        };
        public ColourSetting normalBackground = new ColourSetting(Color.FromRgb(53, 53, 53)) {
            name = SettingNames.normalBackground,
            description = "Should be slightly brighter than 'Dim Background'.",
            category = "Theme"
        };
        public ColourSetting brightBackground = new ColourSetting(Color.FromRgb(71, 71, 71)) {
            name = SettingNames.brightBackground,
            description = "Should be slightly brighter than 'Normal Background'.",
            category = "Theme"
        };
        public ColourSetting uiBackground = new ColourSetting(Color.FromRgb(89, 89, 89)) {
            name = SettingNames.uiBackground,
            description = "Should be slightly brighter than 'Bright Background'.",
            category = "Theme"
        };
        public ColourSetting accentColour = new ColourSetting(Colors.DodgerBlue) {
            name = SettingNames.accentColour,
            description = $"The accent colour of {ProgramData.programName}.",
            category = "Theme"
        };
        public ColourSetting textColour = new ColourSetting(Colors.White) {
            name = SettingNames.textColour,
            description = $"The text and icon colour of {ProgramData.programName}.",
            category = "Theme"
        };
        public ColourSetting goodTextColour = new ColourSetting(Colors.Lime) {
            name = SettingNames.goodTextColour,
            description = "The colour of text that says something good, e.g. 'Yes'",
            category = "Theme"
        };
        public ColourSetting badTextColour = new ColourSetting(Colors.Red) {
            name = SettingNames.badTextColour,
            description = "The colour of text that says something bad, e.g. 'No'",
            category = "Theme"
        };

        // Hidden - Put in default category
        public BoolSetting isFirstTimeLaunch = new BoolSetting(true) {
            name = SettingNames.isFirstTimeLaunch,
            description = "Only true the first time the program is run.",
            category = defaultCategory,
            isHidden = true
        };

        #endregion

        // Constructor

        public Settings() {
            RestoreDefaults(false);
        }

        // Custom Events

        public static event EventHandler<SettingChangedEventArgs> SettingsChanged;

        // Public Functions

        public List<Setting> GetAllSettings() {
            return new List<Setting>() {
                // General
                logDebugMessages,
                showLog,

                // Backups
                autoBackups,
                backupsFolder,
                browseForBackupsFolder,
                numBackups,
                openBackups,

                // Theme
                restoreDefaultTheme,
                dimBackground,
                normalBackground,
                brightBackground,
                uiBackground,
                accentColour,
                textColour,
                goodTextColour,
                badTextColour,

                // Hidden
                isFirstTimeLaunch,
            };
        }

        public List<Setting> GetSettingsInCategory(string category) {
            return GetAllSettings().Where(setting => setting.category.Contains(category)).ToList();
        }

        public void RestoreDefaults(bool shouldSave = true) {
            foreach(Setting setting in GetAllSettings()) {
                if (setting.name == SettingNames.isFirstTimeLaunch) continue;
                setting.RestoreDefault();
            }

            if(shouldSave) Save();
        }

        public void SetSetting(string name, string value, bool changeFromGUI = true) {
            switch (name) {
                case SettingNames.backupsFolder: backupsFolder.value = value; break;
                default:
                    Log.Error($"Could not find the StringSetting named '{name}'");
                    return;
            }

            Log.Info($"Set Setting '{name}' to '{value}'");
            Save();
            SettingsChanged?.Invoke(this, new SettingChangedEventArgs() { changeFromGUI = changeFromGUI });
        }

        public void SetSetting(string name, int value, bool changeFromGUI = true) {
            switch (name) {
                case SettingNames.numBackups: numBackups.value = value; break;
                default:
                    Log.Error($"Could not find the IntSetting named '{name}'");
                    return;
            }

            Log.Info($"Set Setting '{name}' to '{value}'");
            Save();
            SettingsChanged?.Invoke(this, new SettingChangedEventArgs() { changeFromGUI = changeFromGUI });
        }

        public void SetSetting(string name, bool value, bool changeFromGUI = true) {
            switch (name) {
                case SettingNames.logDebugMessages: logDebugMessages.value = value; break;
                case SettingNames.isFirstTimeLaunch: isFirstTimeLaunch.value = value; break;
                default:
                    Log.Error($"Could not find the BoolSetting named '{name}'");
                    return;
            }

            Log.Info($"Set Setting '{name}' to '{value}'");
            Save();
            SettingsChanged?.Invoke(this, new SettingChangedEventArgs() { changeFromGUI = changeFromGUI });
        }

        public void SetSetting(string name, Color value, bool changeFromGUI = true) {
            switch (name) {
                case SettingNames.dimBackground: dimBackground.value = value; break;
                case SettingNames.normalBackground: normalBackground.value = value; break;
                case SettingNames.brightBackground: brightBackground.value = value; break;
                case SettingNames.uiBackground: uiBackground.value = value; break;
                case SettingNames.accentColour: accentColour.value = value; break;
                case SettingNames.textColour: textColour.value = value; break;
                default:
                    Log.Error($"Could not find the ColourSetting named '{name}'");
                    return;
            }

            Log.Info($"Set Setting '{name}' to '{value}'");
            Save();
            LoadTheme();
            SettingsChanged?.Invoke(this, new SettingChangedEventArgs() { changeFromGUI = changeFromGUI });
        }

        public static void LoadTheme() {
            Application.Current.Resources["dimBackgroundBrush"] = new SolidColorBrush(userSettings.dimBackground.value);
            Application.Current.Resources["backgroundBrush"] = new SolidColorBrush(userSettings.normalBackground.value);
            Application.Current.Resources["brightBackgroundBrush"] = new SolidColorBrush(userSettings.brightBackground.value);
            Application.Current.Resources["uiBackgroundBrush"] = new SolidColorBrush(userSettings.uiBackground.value);
            Application.Current.Resources["accentBrush"] = new SolidColorBrush(userSettings.accentColour.value);
            Application.Current.Resources["textBrush"] = new SolidColorBrush(userSettings.textColour.value);

            Application.Current.Resources["accentColour"] = userSettings.accentColour.value;
            RecolourIcons();
        }

        // Private Functions

        private bool ValidateNames() {
            List<string> names = GetAllSettings().Select(setting => setting.name).ToList();
            List<string> uniqueNames = names.Distinct().ToList();
            bool passed = names.Count == uniqueNames.Count;
            if (!passed) {
                for(int i = 0; i < names.Count; i++) {
                    for(int j = 0; j < names.Count; j++) {
                        if (i == j) continue;
                        if (names[i] == names[j]) Log.Warning($"Setting name '{names[i]}' is not unique");
                    }
                }
            }

            return passed;
        }

        private static void RecolourIcons() {
            string newColourHex = StringUtils.ColourToHex(userSettings.textColour.value);
            if (newColourHex == iconColour) return;
            
            List<string> svgsToRecolour = new List<string>() {
                "GUI/Up",
                "GUI/Down",
                "ControlBox/Settings",
                "ControlBox/Move",
                "ControlBox/Minimise",
                "ControlBox/Close",
            };
            foreach(string svg in svgsToRecolour) {
                Log.Debug($"Updating {svg} to {newColourHex}");
                string path = $"{ProgramData.FilePaths.resourcesFolder}\\{svg}.svg";

                string OldText = File.ReadAllText(path);
                Log.Debug($"Read svg file");

                string NewText = OldText.Replace(iconColour.ToLower(), newColourHex.ToLower());
                
                File.WriteAllText(path, NewText);
                Log.Debug($"Wrote svg file");
            }

            iconColour = StringUtils.ColourToHex(userSettings.textColour.value);
            MainWindow.current.controlBox.RefreshIcons();
        }

        // Data Functions

        public static void Save() {
            userSettings.ValidateNames();
            string json = JsonConvert.SerializeObject(userSettings, Formatting.Indented);
            File.WriteAllText(ProgramData.FilePaths.settingsFile, json);
        }

        public static void Load() {
            if (!File.Exists(ProgramData.FilePaths.settingsFile)) {
                userSettings = new Settings();
                Save();
            }

            string json = File.ReadAllText(ProgramData.FilePaths.settingsFile);
            userSettings = JsonConvert.DeserializeObject<Settings>(json);
            iconColour = StringUtils.ColourToHex(userSettings.textColour.value);
            LoadTheme();
        }
    }

    public static class SettingNames {
        // General
        public const string logDebugMessages = "Log Debug Messages";
        public const string showLog = "Show Log In Explorer";
        public const string test = "Test Combo";

        // Backups
        public const string autoBackup = "Perform Automatic Backups";
        public const string backupsFolder = "Backups Folder";
        public const string browseForBackupsFolder = "Browse For Backups Folder";
        public const string numBackups = "Backup Count";
        public const string openBackups = "Backups Manager";

        // Theme
        public const string restoreDefaultTheme = "Restore Default Theme";
        public const string dimBackground = "Dim Background Colour";
        public const string normalBackground = "Normal Background Colour";
        public const string brightBackground = "Bright Background Colour";
        public const string uiBackground = "UI Background Colour";
        public const string accentColour = "Accent Colour";
        public const string textColour = "Text Colour";
        public const string goodTextColour = "Good Text Colour";
        public const string badTextColour = "Bad Text Colour";

        // Hidden
        public const string isFirstTimeLaunch = "Is First Time Launch";
    }

    public class SettingChangedEventArgs : EventArgs {
        public bool changeFromGUI;
    }
}

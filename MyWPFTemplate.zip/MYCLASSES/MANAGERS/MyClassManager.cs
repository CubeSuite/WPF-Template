﻿using $safeprojectname$.MyClasses;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public static class MyClassManager
    {
        // Objects & Variables

        private static Dictionary<int, MyClass> myClasses = new Dictionary<int, MyClass>();

        // Public Functions

        public static void addMyClass(MyClass myClass) {
            myClass.id = getNewID();
            myClasses.Add(myClass.id, myClass);
            Log.Debug($"Added MyClass with id '{myClass.id}'");
        }

        public static void UpdateMyClass(MyClass myClass) {
            if (DoesMyClassExist(myClass)) {
                myClasses[myClass.id] = myClass;
                Log.Debug($"Updated MyClass with id '{myClass.id}'");
            }
            else {
                Log.Error($"Could not update unknown MyClass with id '{myClass.id}'");
            }
        }

        public static int getMyClassesCount() {
            return myClasses.Count;
        }

        public static bool DoesMyClassExist(int id) {
            return myClasses.ContainsKey(id);
        }

        // Private Functions

        private static int getNewID() {
            if (getMyClassesCount() == 0) return 0;
            else return myClasses.Keys.Max() + 1;
        }

        // Data Functions

        public static void Save() {
            string json = JsonConvert.SerializeObject(myClasses.Values.ToList());
            File.WriteAllText(ProgramData.FilePaths.myClassSaveFile, json);
        }

        public static void Load() {
            if (File.Exists(ProgramData.FilePaths.myClassSaveFile)) {
                string json = File.ReadAllText(ProgramData.FilePaths.myClassSaveFile);
                List<MyClass> myClasses = JsonConvert.DeserializeObject<List<MyClass>>(json);
                foreach(MyClass myClass in myClasses) {
                    addMyClass(myClass);
                }
            }
        }

        #region Overloads

        // Public Functions

        public static bool DoesMyClassExist(MyClass myClass) {
            return DoesMyClassExist(myClass.id);
        }

        #endregion
    }
}

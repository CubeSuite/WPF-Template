﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.MyClasses
{
    public class MyClass : INotifyPropertyChanged
    {
        // Members
        private int _id;
        public int id {
            get => _id;
            set {
                _id = value;
                OnPropertyChanged("id");
            }
        }

        private string _name;
        public string name {
            get => _name;
            set {
                _name = value;
                OnPropertyChanged("name");
            }
        }

        // Constructors

        public MyClass() { }
        public MyClass fromJson(string json) {
            return JsonConvert.DeserializeObject<MyClass>(json);
        }

        // Public Functions

        public string toJson(bool indented = true) {
            return JsonConvert.SerializeObject(this, indented ? Formatting.Indented : Formatting.None);
        }

        // Private Functions

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName) {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

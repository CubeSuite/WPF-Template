﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Automation.Peers;

namespace $safeprojectname$
{
	#region MyEnum

	public enum MyEnum {
		Item1,
		Item2,
        Null,
	}

	public static partial class StringUtils {
		public static MyEnum GetMyEnumFromName(string name) {
			switch (name) {
				case "Item1": return MyEnum.Item1;
				case "Item2": return MyEnum.Item2;

                default:
					Log.Error($"No member of MyEnum has name '{name}'");
					return MyEnum.Null;
			}
		}

		public static string GetMyEnumName(MyEnum myEnum) {
			switch (myEnum) {
				case MyEnum.Item1: return "Item1";
				case MyEnum.Item2: return "Item2";
				case MyEnum.Null: return "Null";
				default:
					string defaultName = Enum.GetName(typeof(MyEnum), myEnum);
                    Log.Error($"Name not set for MyEnum member: {defaultName}");
					return defaultName;
			}
		}

		public static List<string> GetAllMyEnumNames() {
			List<string> allNames = new List<string>();
			foreach(MyEnum myEnum in Enum.GetValues(typeof(MyEnum))) {
				string name = GetMyEnumName(myEnum);
				if(name != "Null") allNames.Add(name);
			}

			return allNames;
		}

		public static string GetAllMyEnumNamesForCombo() {
			return string.Join("|", GetAllMyEnumNames());
		}
	}

	#endregion
}
